## BONIPHACE MD
 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 <a href="https://github.com/DenverCoder1/readme-typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Time+New+Roman&color=red&size=25&center=true&vCenter=true&width=600&height=100&lines=I'm+Boniphace+md+Created+by+Boniphace.&heart;++;Self-taught+Back-Created+By,;Ibrahim+Adams+Am+The,;Best+Is+Bot+For+You+To,;Deploy..<3"></a>
 <a href="https://telegra.ph/file/a426523c1f8b7ee7430f1.jpg">
 <img alt="BONIPHACE-MD" height="300" src="https://telegra.ph/file/a426523c1f8b7ee7430f1.jpg">

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
</h1> 
<p align="center">l introduce <b>BONIPHACE-MD</b>, a powerful simple WhatsApp bot </p>

</p>
  <p align="center">
<a href="https://github.com/boniphace478?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/boniphace478?label=Followers&style=social"></a>
<a href="https://github.com/boniphace478/boniphace-md/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/boniphace478/boniphace-md?&style=social"></a>
<a href="https://github.com/boniphace478/boniphace-md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/boniphace478/boniphace-md?style=social"></a>
<a href="https://github.com/boniphace478/boniphace-md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/boniphace478/boniphace-md?label=Watching&style=social"></a>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{boniphace478}/count.svg" alt="Boniphace-md :: Visitor's Count"/></p>

---


</a>
  <div align="center">
  <img src="https://spogit.vercel.app/api?theme=dark&black=true&scan=true" alt="Widget with the current Spotify song"  />
</div>

---

<p align="center">
  <a href="https://github.com/boniphace478/Boniphace-md"><b>Boniphace-md</b></a> Support Deploy On...
</p>

<p align="center">
  <a href="https://github.com/boniphace478/Boniphace-Md/blob/main/temp/deploy-on-vps.md"><img src="https://img.shields.io/badge/self hosting-3d1513?style=for-the-badge&logo=serverless&logoColor=FD5750"></a>
  <a href="https://dashboard.heroku.com/new?template=https://github.com/boniphace478/Boniphace-Md/tree/main"><img src="https://img.shields.io/badge/heroku-9d7acc?style=for-the-badge&logo=heroku&logoColor=430098"></a>
  <a href="https://youtu.be/izoxfW3anrU"><img src="https://img.shields.io/badge/CodeSpace-green?colorA=%23ff000&colorB=%23017e40&style=for-the-badge&logo=git&logoColor=white"></a>
</p>



    
 
 



---





## HOW TO DEPLOY BONIPHACE MD


## 1.FIRST STEP 
## Fork Boniphace Md Repo
👇 👇  👇 👇
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+ℙ𝕃𝔼𝔸𝕊𝔼+𝔽𝕆ℝ𝕂+𝕋ℍ𝔼+ℝ𝔼ℙ𝕆)](https://git.io/typing-svg)
 
- <a href="https://github.com/boniphace478/BONIPHACE-MD/fork"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/FORK THIS REPO-h?color=darkblue&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

star✨ my repo if you like this bot🤖


## 2.SECOND STEP 


 GET SESSION ID BY

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+𝕋ℍ𝕀𝕊+𝕀𝕊+𝕊𝔼𝕊𝕊𝕀𝕆ℕ+𝕊𝔼𝕋𝔼😎)](https://git.io/typing-svg)

### QR SITE

- <a href="https://anthony-boniphace.onrender.com/wasiqr"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/QR CODE-h?color=green&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

### SESSION SITE

- <a href="https://anthony-boniphace.onrender.com"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/PAIRING CODE-h?color=green&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>





### 3.THIRD STEP 
1. If You Don't Have An Account On Heroku**

   <br>
    <a 
- <a align="center"><a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/Create%20Account%20Now-darkblue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

### 2. If You Have Account On Heroku**👇 👇 👇

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+100%+𝗦𝗔𝗙𝗘+𝗢𝗡+𝗛𝗘𝗥𝗢𝗞𝗨)](https://git.io/typing-svg)
 
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

   <br>
    - <a href='https://dashboard.heroku.com/new?template=https://github.com/boniphace478/BONIPHACE-MD' target="_darkblue"><img alt='DEPLOY TO HEROKU' src="https://img.shields.io/badge/Deploy%20To%20Heroku-darkblue?style=for-the-badge&logo=heroku" width="200" height="38.45"/></a></p>


### DEPLOY ON RENDER

1. If you don't have an account in RENDER, create one and deploy.
    <br>
    <a href='https://dashboard.render.com/select-repo?type=web' target="_darkblue"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render&logoColor=white'/></a>


   ###

CONTACT DEVELOPER ON WHATSAPP 

<a href="https://wa.link/4d9cpj" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/boniphace tech contact -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />


  
 
<a href="https://whatsapp.com/channel/0029VaiMm7d4yltT51HS1T1G" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ BONIPHACE_TECH  CHANNEL -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
 

## License

The WhatsApp Bot BONIPHACE-MD is released under the [MIT License](https://opensource.org/licenses/MIT).
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

🌟 THANK YOU FOR CHOOSING BONIPHACE-MD 🌟
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## DEVELOPERS :

- [**BONIPHACE TECH**](https://github.com/boniphace478)
- [**Developers YT**](https://youtube.com/@anthonyboniphace?si=86VHGM7BZ4Q_OQYO)
 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 
★THANKS BE TO GOG 🙏. ©
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

     

